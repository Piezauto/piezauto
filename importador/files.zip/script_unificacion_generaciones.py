"""Script de unificación generaciones v3 - optimizado con apply vectorizado.
Aplica solo a UN proveedor por ejecución para evitar timeouts.
"""
import pandas as pd
import re
import sys
import warnings
warnings.filterwarnings('ignore')

MAPA_MODELO_A_CONVENCION = {
    'gol': 'VW_G', 'saveiro': 'VW_G', 'senda': 'VW_G', 'gacel': 'VW_G',
    'polo classic': 'VW_G', 'caddy': 'VW_G', 'country': 'VW_G',
    'voyage': 'VW_G', 'fox': 'VW_G', 'suran': 'VW_G', 'pointer': 'VW_G',
    'gol country': 'VW_G', 'gol trend': 'VW_G',
    'golf': 'VW_MK', 'jetta': 'VW_MK',
    'passat': 'VW_B',
    'bora': 'VW_A', 'vento': 'VW_A',
    'escort': 'FORD_MK', 'sierra': 'FORD_MK', 'mondeo': 'FORD_MK',
    'focus': 'FORD_MK', 'fiesta': 'FORD_MK', 'ka': 'FORD_MK',
    'palio': 'FIAT_FASE', 'siena': 'FIAT_FASE', 'weekend': 'FIAT_FASE',
    'strada': 'FIAT_FASE', 'punto': 'FIAT_FASE', 'idea': 'FIAT_FASE',
    'berlingo': 'CIT_F_ROM', 'jumpy': 'CIT_F_ROM', 'jumper': 'CIT_F_ROM',
    'xsara picasso': 'CIT_F_ROM',
    '206': 'PEU_F_ARA', '207': 'PEU_F_ARA', '208': 'PEU_F_ARA',
    '301': 'PEU_F_ARA', '307': 'PEU_F_ARA', '308': 'PEU_F_ARA',
    '405': 'PEU_F_ARA', '406': 'PEU_F_ARA', '407': 'PEU_F_ARA',
    '408': 'PEU_F_ARA', '508': 'PEU_F_ARA',
    '2008': 'PEU_F_ARA', '3008': 'PEU_F_ARA',
    'partner': 'PEU_F_ROM', 'boxer': 'PEU_F_ROM', 'expert': 'PEU_F_ROM',
}

MODELOS_ORD = sorted(MAPA_MODELO_A_CONVENCION.keys(), key=len, reverse=True)
PATRON_MODELOS = re.compile(r'\b(' + '|'.join(re.escape(m) for m in MODELOS_ORD) + r')\b', re.IGNORECASE)

ROM_A_ARA = {'I':'1','II':'2','III':'3','IV':'4','V':'5','VI':'6','VII':'7','VIII':'8'}
ARA_A_ROM = {1:'I',2:'II',3:'III',4:'IV',5:'V',6:'VI',7:'VII',8:'VIII'}


def normalizar_aplicacion(texto):
    if not isinstance(texto, str) or not texto.strip():
        return texto, None
    
    m = PATRON_MODELOS.search(texto.lower())
    if not m:
        return texto, None
    convencion = MAPA_MODELO_A_CONVENCION[m.group(1)]
    
    if convencion == 'VW_G':
        m2 = re.search(r'\bFASE\s*([1-4IVXivx]+)\b', texto, re.IGNORECASE)
        if m2:
            num = ROM_A_ARA.get(m2.group(1).upper(), m2.group(1))
            nuevo = re.sub(r'\bFASE\s*[1-4IVXivx]+\b', f'G{num}', texto, count=1, flags=re.IGNORECASE)
            if nuevo != texto:
                return nuevo, 'VW Gol/Saveiro/etc: FASE X → GX'
    
    elif convencion == 'VW_MK':
        m2 = re.search(r'\bG([1-9])\b', texto)
        if m2:
            nuevo = re.sub(r'\bG[1-9]\b', f'MK{m2.group(1)}', texto, count=1)
            return nuevo, 'VW Golf/Jetta: GX → MKX'
    
    elif convencion == 'FIAT_FASE':
        m2 = re.search(r'\bG([1-4])\b', texto)
        if m2:
            num = ARA_A_ROM.get(int(m2.group(1)))
            if num:
                nuevo = re.sub(r'\bG[1-4]\b', f'FASE {num}', texto, count=1)
                return nuevo, 'Fiat Palio/Siena/etc: GX → FASE X'
        m2 = re.search(r'\bF([1-4])\b', texto)
        if m2:
            num = ARA_A_ROM.get(int(m2.group(1)))
            if num:
                nuevo = re.sub(r'\bF[1-4]\b', f'FASE {num}', texto, count=1)
                return nuevo, 'Fiat Palio/Siena/etc: FX → FASE X'
    
    elif convencion == 'PEU_F_ARA':
        m2 = re.search(r'\bF([IVXivx]+)\b', texto)
        if m2 and len(m2.group(1)) <= 4:
            num = ROM_A_ARA.get(m2.group(1).upper())
            if num:
                nuevo = re.sub(r'\bF[IVXivx]+\b', f'F{num}', texto, count=1)
                return nuevo, 'Peugeot 206/207/etc: FI/FII → F1/F2'
    
    elif convencion == 'PEU_F_ROM':
        m2 = re.search(r'\bF([1-4])\b', texto)
        if m2:
            num = ARA_A_ROM.get(int(m2.group(1)))
            if num:
                nuevo = re.sub(r'\bF[1-4]\b', f'F{num}', texto, count=1)
                return nuevo, 'Peugeot Partner/Boxer/Expert: F1/F2 → FI/FII'
    
    elif convencion == 'CIT_F_ROM':
        m2 = re.search(r'\bF([1-4])\b', texto)
        if m2:
            num = ARA_A_ROM.get(int(m2.group(1)))
            if num:
                nuevo = re.sub(r'\bF[1-4]\b', f'F{num}', texto, count=1)
                return nuevo, 'Citroën Berlingo/Jumpy/Jumper: F1/F2 → FI/FII'
    
    return texto, None


def procesar_aplicaciones(texto):
    if not isinstance(texto, str) or not texto.strip():
        return texto, None
    
    sep = None
    if ' / ' in texto:
        partes = texto.split(' / ')
        sep = ' / '
    elif ';' in texto:
        partes = [p.strip() for p in texto.split(';')]
        sep = '; '
    else:
        partes = [texto]
    
    nuevas = []
    reglas = []
    for p in partes:
        np, regla = normalizar_aplicacion(p)
        nuevas.append(np)
        if regla:
            reglas.append(regla)
    
    if not reglas:
        return texto, None
    nuevo = (sep or '').join(nuevas)
    if nuevo == texto:
        return texto, None
    return nuevo, '; '.join(set(reglas))


def procesar_proveedor(prov):
    """Procesa UN proveedor y devuelve cambios detectados."""
    print(f'  Procesando {prov}...')
    df = pd.read_excel(f'/mnt/user-data/outputs/{prov}.xlsx', sheet_name='Normalizado')
    
    cambios = []
    
    # Vectorizar usando apply
    desc_resultados = df['descripcion_original'].apply(normalizar_aplicacion)
    apl_resultados = df['aplicaciones'].apply(procesar_aplicaciones)
    
    for idx, ((dnew, dregla), (anew, aregla)) in enumerate(zip(desc_resultados, apl_resultados)):
        codigo = df.iloc[idx]['codigo_proveedor']
        if dregla and dnew != df.iloc[idx]['descripcion_original']:
            cambios.append({
                'proveedor': prov, 'codigo': codigo, 'campo': 'descripcion_original',
                'original': df.iloc[idx]['descripcion_original'][:200],
                'corregido': dnew[:200], 'regla': dregla,
            })
        if aregla and anew != df.iloc[idx]['aplicaciones']:
            cambios.append({
                'proveedor': prov, 'codigo': codigo, 'campo': 'aplicaciones',
                'original': str(df.iloc[idx]['aplicaciones'])[:200],
                'corregido': anew[:200], 'regla': aregla,
            })
    
    return cambios


# Ejecución principal
proveedores = ['Cromosol','BBA','Otero','DM','Farosdam','Vaer','Delviso',
               'Expoyer','SG','Surpiezas','Bark1','Francar','Fragata','LAM']

print('=== Script v3 optimizado - PREVIEW de cambios ===\n')
todos_cambios = []
print(f'{"Proveedor":<12} {"Cambios":>10}')
print('-' * 25)
for prov in proveedores:
    cambios = procesar_proveedor(prov)
    todos_cambios.extend(cambios)
    print(f'{prov:<12} {len(cambios):>10,}')

print('-' * 25)
print(f'{"TOTAL":<12} {len(todos_cambios):>10,}')
print()

df_cambios = pd.DataFrame(todos_cambios)

# Resumen por regla (expandir reglas múltiples)
reglas_exp = []
for r in df_cambios['regla']:
    for sub in str(r).split('; '):
        reglas_exp.append(sub)
print('Cambios por regla:')
print(pd.Series(reglas_exp).value_counts().to_string())

# Guardar PREVIEW final
ruta = '/mnt/user-data/outputs/update_generaciones_PREVIEW.xlsx'
with pd.ExcelWriter(ruta, engine='xlsxwriter') as writer:
    df_cambios.to_excel(writer, sheet_name='Cambios propuestos', index=False)
    
    df_resumen = pd.DataFrame({'regla': reglas_exp}).value_counts().reset_index()
    df_resumen.columns = ['regla', 'cantidad']
    df_resumen.to_excel(writer, sheet_name='Resumen por regla', index=False)
    
    df_por_prov = df_cambios.groupby('proveedor').size().reset_index(name='cantidad')
    df_por_prov.to_excel(writer, sheet_name='Por proveedor', index=False)
    
    wb = writer.book
    for sheet_name in writer.sheets:
        ws = writer.sheets[sheet_name]
        ws.freeze_panes(1, 0)
        ws.set_row(0, 30)

print(f'\nPREVIEW v3 generado: {ruta}')
print(f'Total cambios: {len(df_cambios)}')

# También guardar el script en outputs
import shutil
shutil.copy('/tmp/script_gen_v3.py', '/mnt/user-data/outputs/script_unificacion_generaciones.py')
print(f'Script v3 guardado en outputs')
