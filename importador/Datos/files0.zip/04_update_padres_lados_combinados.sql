-- ═══════════════════════════════════════════════════════════
-- UPDATE PADRES LADOS_COMBINADOS - 02/05/2026
-- Decisión dueño: padres NO deben ser vendibles
-- ═══════════════════════════════════════════════════════════

BEGIN;

-- Solo ejecutar si la verificación detectó padres con activo_venta = TRUE
-- (Query 1 del archivo 01_verificar_padres_lados.sql retornó > 0)

UPDATE cat_skus
SET activo_venta = FALSE,
    updated_at = NOW()
WHERE tipo_lados = 'lados_combinados'
  AND es_padre = TRUE
  AND activo_venta = TRUE;

-- Verificación post-UPDATE:
-- SELECT COUNT(*) FROM cat_skus
-- WHERE tipo_lados = 'lados_combinados'
--   AND es_padre = TRUE
--   AND activo_venta = TRUE;
-- Resultado esperado: 0

COMMIT;

-- ═══════════════════════════════════════════════════════════
-- NOTAS:
-- - Este UPDATE solo se ejecuta si la verificación previa
--   detectó padres mal configurados
-- - Los padres siguen activos (activo = TRUE) para sincronización
-- - Solo se cambia activo_venta = FALSE para que no aparezcan
--   en canales de venta
-- ═══════════════════════════════════════════════════════════
