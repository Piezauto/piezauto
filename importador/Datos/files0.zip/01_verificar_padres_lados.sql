-- ═══════════════════════════════════════════════════════════
-- VERIFICACIÓN PADRES LADOS_COMBINADOS - 02/05/2026
-- ═══════════════════════════════════════════════════════════

-- Query 1: Contar padres mal configurados (activo_venta = TRUE)
SELECT COUNT(*) as padres_mal_configurados
FROM cat_skus
WHERE tipo_lados = 'lados_combinados'
  AND es_padre = TRUE
  AND activo_venta = TRUE;

-- Query 2: Ver detalle de padres mal configurados (si hay)
SELECT 
    id,
    codigo_piezauto,
    tipo_lados,
    es_padre,
    activo,
    activo_venta,
    familia_id,
    proveedor_original
FROM cat_skus
WHERE tipo_lados = 'lados_combinados'
  AND es_padre = TRUE
  AND activo_venta = TRUE
LIMIT 20;

-- Query 3: Verificar total de padres lados_combinados
SELECT COUNT(*) as total_padres_lados_combinados
FROM cat_skus
WHERE tipo_lados = 'lados_combinados'
  AND es_padre = TRUE;

-- Query 4: Verificar hijos D/I activos para venta
SELECT COUNT(*) as hijos_activos_venta
FROM cat_skus
WHERE tipo_lados = 'lados_combinados'
  AND es_padre = FALSE
  AND activo_venta = TRUE;

-- Resultado esperado Query 1: 0
-- Resultado esperado Query 3: ~8.188 padres
-- Resultado esperado Query 4: ~16.376 hijos (8.188 × 2)
