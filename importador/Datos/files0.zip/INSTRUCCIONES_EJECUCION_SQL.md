# INSTRUCCIONES EJECUCIÓN SQL - Sprint 5 Cierre
**Fecha:** 02/05/2026
**Orden de aplicación:** CRÍTICO - ejecutar en este orden

═══════════════════════════════════════════════════════════
## PASO 1: VERIFICACIÓN PADRES LADOS_COMBINADOS
═══════════════════════════════════════════════════════════

**Archivo:** `01_verificar_padres_lados.sql`

**Ejecutar en Supabase SQL Editor:**

```sql
-- Query 1: Contar padres mal configurados
SELECT COUNT(*) as padres_mal_configurados
FROM cat_skus
WHERE tipo_lados = 'lados_combinados'
  AND es_padre = TRUE
  AND activo_venta = TRUE;
```

**Resultado esperado:** 0

**Si es > 0:** Ejecutar Query 2 para ver detalle, luego aplicar paso 4.

```sql
-- Query 3: Total padres (debe ser ~8.188)
SELECT COUNT(*) as total_padres
FROM cat_skus
WHERE tipo_lados = 'lados_combinados'
  AND es_padre = TRUE;

-- Query 4: Total hijos activos venta (debe ser ~16.376)
SELECT COUNT(*) as hijos_activos
FROM cat_skus
WHERE tipo_lados = 'lados_combinados'
  AND es_padre = FALSE
  AND activo_venta = TRUE;
```

═══════════════════════════════════════════════════════════
## PASO 2: UPDATE GENERACIONES (3,844 cambios)
═══════════════════════════════════════════════════════════

**Archivo:** `02_update_generaciones_aplicar.sql`

**Qué hace:**
- Normaliza generaciones VW: G1, G2, G3, G4 (Gol/Saveiro)
- Normaliza generaciones VW: MK (Golf/Jetta)
- Normaliza generaciones Fiat: FASE I, FASE II, etc (Palio/Siena)
- Normaliza generaciones Peugeot: F1, F2, etc
- Normaliza generaciones Citroen: F I, F II, etc

**Ejecutar en Supabase:**
Copiar TODO el contenido del archivo y ejecutar.

**Duración estimada:** 30-60 segundos

**Verificación post-ejecución:**
```sql
SELECT COUNT(*) FROM cat_skus
WHERE descripcion_original LIKE '%FASE%' 
  AND descripcion_original LIKE '%Gol%';
```
Resultado esperado: ~0 (Gol no usa FASE, usa G)

═══════════════════════════════════════════════════════════
## PASO 3: UPDATE FAMILIA REVISAR (439 SKUs)
═══════════════════════════════════════════════════════════

**Archivo:** `03_update_revisar_aplicar.sql`

**Qué hace:**
- Asigna familia correcta a 439 SKUs que estaban en REVISAR
- Resuelve 436 SKUs (quedan solo 3 en REVISAR)
- Los 3 restantes son Expoyer con descripción "0" (CPO Mes 2-3)

**Ejecutar en Supabase:**
Copiar TODO el contenido del archivo y ejecutar.

**Duración estimada:** 10-20 segundos

**Verificación post-ejecución:**
```sql
SELECT COUNT(*) FROM cat_skus s
JOIN cat_familias f ON f.id = s.familia_id
WHERE f.nombre = 'REVISAR';
```
Resultado esperado: 3

═══════════════════════════════════════════════════════════
## PASO 4: UPDATE PADRES LADOS_COMBINADOS (condicional)
═══════════════════════════════════════════════════════════

**Archivo:** `04_update_padres_lados_combinados.sql`

**SOLO EJECUTAR SI:**
El Paso 1 (Query 1) retornó > 0 padres mal configurados.

**Qué hace:**
- Cambia activo_venta = FALSE en todos los padres lados_combinados
- Los padres siguen activo = TRUE (para sincronización interna)
- Solo afecta la visibilidad en canales de venta

**Ejecutar en Supabase:**
Copiar TODO el contenido del archivo y ejecutar.

**Duración estimada:** 5-10 segundos

**Verificación post-ejecución:**
```sql
SELECT COUNT(*) FROM cat_skus
WHERE tipo_lados = 'lados_combinados'
  AND es_padre = TRUE
  AND activo_venta = TRUE;
```
Resultado esperado: 0

═══════════════════════════════════════════════════════════
## RESUMEN TIMING
═══════════════════════════════════════════════════════════

Total tiempo estimado: 2-3 minutos

1. Verificación padres: 30 seg
2. UPDATE generaciones: 60 seg
3. UPDATE familia REVISAR: 20 seg
4. UPDATE padres (si aplica): 10 seg

═══════════════════════════════════════════════════════════
## ORDEN DE EJECUCIÓN
═══════════════════════════════════════════════════════════

✅ PASO 1 → ✅ PASO 2 → ✅ PASO 3 → ✅ PASO 4 (si es necesario)

═══════════════════════════════════════════════════════════
## DESPUÉS DE COMPLETAR
═══════════════════════════════════════════════════════════

**Reportar a Coordinador:**
- Query 1 resultado: X padres mal configurados
- UPDATE generaciones: OK
- UPDATE familia REVISAR: OK
- UPDATE padres (si aplicó): OK

**Pendiente para siguiente fase:**
- surpiezas_fix_precios.sql (618 SKUs)
- DDL cat_stock_proveedor
- INSERT stock v6 (278.090 filas)

═══════════════════════════════════════════════════════════
