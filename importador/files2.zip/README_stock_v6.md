# Paquete stock v6 — Pre-carga para `cat_stock_proveedor`

**De:** COO — Comisión Directiva
**Para:** CTO + Coordinador
**Fecha:** 28 de abril de 2026
**Estado:** Listo para INSERT en `cat_stock_proveedor` cuando el CTO aplique el DDL aprobado.

---

## Contenido del paquete

- `stock_v6_pre_carga.csv` — datos para INSERT masivo (278.090 filas).
- `stock_v6_pre_carga.xlsx` — versión XLSX con resumen y muestras (para auditoría humana).

---

## Modelo de datos

CSV con 5 columnas:

| Columna | Tipo | Descripción |
|---|---|---|
| `proveedor` | string | Nombre del proveedor (Cromosol / Expoyer / Fragata) |
| `codigo_proveedor` | string | Código del SKU según proveedor |
| `ubicacion` | string | Sucursal o ubicación específica |
| `stock_estado` | enum | disponible / consultar / crítico / sin_stock |
| `fecha_lectura` | datetime ISO | Cuándo se hizo la lectura |

---

## Estados canónicos (4 valores ENUM)

| Estado | Significado | Uso operativo |
|---|---|---|
| `disponible` | Pieza presente, lista para entregar | Mostrar verde, ofrecer al cliente |
| `consultar` | Probable que haya, requiere confirmación al proveedor | Mostrar amarillo, llamar antes de prometer |
| `crítico` | Hay poca cantidad, urgente reabastecer | Mostrar naranja, marcar para reposición |
| `sin_stock` | No hay | Mostrar rojo, ofrecer alternativa de otro proveedor |

---

## Mapeo desde proveedor

| Proveedor | Valor origen | Estado canónico |
|---|---|---|
| Cromosol | "A Consultar" | consultar |
| Cromosol | "No Disponible" | sin_stock |
| Expoyer | "Disponible" | disponible |
| Expoyer | "Crítico" | crítico |
| Fragata | "SI" | disponible |
| Fragata | "SIN STOCK" | sin_stock |

---

## Distribución de filas por proveedor

| Proveedor | Filas | Ubicaciones | Códigos únicos |
|---|---:|---|---:|
| Cromosol | 168.364 | consolidado + 6 sucursales | 24.052 |
| Expoyer | 101.463 | central | 101.459 |
| Fragata | 8.263 | central | 8.263 |
| **TOTAL** | **278.090** | | |

### Cromosol — ubicaciones

7 valores posibles en el campo `ubicacion`:
- `consolidado` — stock central agregado del proveedor (campo Stock del XLSX)
- `AVELLANEDA`, `HOOKE`, `MENDOZA`, `PAYSANDU`, `SAN JUSTO`, `TUCUMAN` — sucursales

Cada SKU tiene típicamente 7 filas (1 consolidado + 6 sucursales), salvo SKUs donde alguna sucursal no declara estado.

### Expoyer — ubicación

1 valor posible: `central`. Expoyer no desglosa stock por sucursal.

### Fragata — ubicación

1 valor posible: `central`. Fragata es proveedor con depósito único (línea Herrajes Fragata).

---

## Distribución por estado

| Estado | Cantidad | % del total |
|---|---:|---:|
| sin_stock | 108.435 | 39,0% |
| disponible | 104.130 | 37,4% |
| crítico | 36.187 | 13,0% |
| consultar | 29.338 | 10,6% |

---

## Proveedores excluidos del paquete

Por decisión del dueño (28/04/2026), **NO se inventa stock para proveedores que no lo declaran** en sus listas:

| Proveedor | Motivo de exclusión |
|---|---|
| Surpiezas | No tiene campo de stock en su XLSX |
| BBA | No declara stock en su lista (mecánica de Cromosol pero sin stock propio) |
| Otero | No declara stock |
| DM | No declara stock |
| Farosdam | No declara stock |
| Vaer | No declara stock |
| Delviso | No declara stock |
| SG | No declara stock |
| Bark1 | No declara stock |
| Francar | No declara stock |
| LAM | No declara stock |
| Stellantis | Aún no cargado en sistema; cuando se cargue, evaluar |

Para estos proveedores, los SKUs en `cat_skus` quedan **sin registro en `cat_stock_proveedor`**. El sistema interpreta la ausencia de fila como "stock no declarado" (NO como "sin stock").

---

## Validación cruzada con catálogo cargado

Los códigos del CSV de stock se validaron contra los códigos de SKU cargados en el catálogo Piezauto:

| Proveedor | Match perfecto | Solo en stock | Solo en catálogo |
|---|---:|---:|---:|
| Cromosol | 24.045 / 24.045 | 7 (códigos de flete descartados) | 0 |
| Expoyer | 94.910 / 101.306 | 6.549 | 6.396 |
| Fragata | 8.262 / 8.262 | 1 | 0 |

**Sobre el desfase Expoyer (6.549 + 6.396 códigos)**: las listas de stock y catálogo de Expoyer son archivos distintos generados en momentos distintos, por eso hay desfase temporal entre ambos. **No es un bug del paquete.** Cuando llegue una sincronización futura, el CTO va a poder reconciliar:

- Códigos en stock pero NO en catálogo: el CTO puede hacer INSERT a `cat_stock_proveedor` igual (quedan huérfanos hasta que el catálogo se actualice) o descartar esos registros.
- Códigos en catálogo pero SIN stock: el sistema interpreta "stock no declarado", coherente.

---

## Instrucciones para el CTO

### Pre-requisito: DDL `cat_stock_proveedor` aplicado

Modelo aprobado en la conversación con CTO (Sprint 4-5). El campo `stock_estado` debe ser ENUM con los 4 valores: `disponible`, `consultar`, `crítico`, `sin_stock`.

### Cómo cargar

```python
import pandas as pd
df = pd.read_csv('stock_v6_pre_carga.csv')

# INSERT por batches de 1000 filas para no saturar
for i in range(0, len(df), 1000):
    batch = df.iloc[i:i+1000]
    insert_batch_to_cat_stock_proveedor(batch)
```

### Política sobre códigos huérfanos (recomendación COO)

**Opción A — descartar huérfanos**: hacer INSERT solo cuando el código exista en `cat_skus`. Los 6.549 códigos Expoyer huérfanos se ignoran en esta carga.

**Opción B — cargar todo**: hacer INSERT de todas las filas. Los huérfanos quedan en `cat_stock_proveedor` sin FK válida (depende de cómo esté el constraint).

**Mi voto: Opción A** (idempotencia limpia). Los 6.549 huérfanos se reactivarán automáticamente cuando llegue una actualización del catálogo Expoyer.

---

## Pendientes que NO se resuelven con este paquete

Los siguientes pendientes siguen abiertos y requieren coordinación posterior:

- **Sincronización recurrente de stock**: este es un snapshot puntual. Cuando el CTO termine el módulo de sync, voy a poder generar pasadas semanales automáticamente.
- **Mapeo de sucursales Cromosol a "ubicaciones físicas Piezauto"**: ahora cargamos el nombre del proveedor (AVELLANEDA, HOOKE, etc.). Cuando Piezauto tenga sus propias sucursales en producción, puede que quieran un mapeo "depósito Cromosol → sucursal Piezauto cercana".
- **Stellantis**: cuando se cargue al sistema, evaluar si trae stock o no.

---

*— COO, Comisión Directiva Piezauto*
